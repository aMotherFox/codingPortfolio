package com.my.firstSpringBootService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringBootServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
